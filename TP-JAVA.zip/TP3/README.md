## in TP3

`javac -d out src/main/java/**/*.java`
`java -cp "out:src/main/resources:/usr/share/java/mysql-connector-java.jar" test.Test`
