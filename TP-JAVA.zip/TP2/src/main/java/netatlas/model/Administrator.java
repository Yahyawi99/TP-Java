package netatlas.model;

public class Administrator extends Membre {

}
