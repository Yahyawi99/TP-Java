package bean;

import java.sql.Date;
import java.util.*;

public class Employee {
    private int Matricule;
    private String Nom;
    private String Prenom;
    private Date dateEmbaucheD;
    private String sexe;
    private ArrayList<String> specialite;

    public Employee(int Matricule, String Nom, String Prenom, Date dateEmbaucheD, String sexe,
            ArrayList<String> specialite) {
        this.Matricule = Matricule;
        this.Nom = Nom;
        this.Prenom = Prenom;
        this.dateEmbaucheD = dateEmbaucheD;
        this.sexe = sexe;
        this.specialite = specialite;

    }

    public Employee() {

    }

    // Getters
    public int getMatricule() {
        return Matricule;
    }

    public String getNom() {
        return Nom;
    }

    public String getPrenom() {
        return Prenom;
    }

    public Date getDateEmbaucheD() {
        return dateEmbaucheD;
    }

    public String getSexe() {
        return sexe;
    }

    // Setters
    public void setMatricule(int Matricule) {
        this.Matricule = Matricule;
    }

    public void setNom(String Nom) {
        this.Nom = Nom;
    }

    public void setPrenom(String Prenom) {
        this.Prenom = Prenom;
    }

    public void setDateEmbaucheD(Date dateEmbaucheD) {
        this.dateEmbaucheD = dateEmbaucheD;
    }

    public void setSexe(String sexe) {
        this.sexe = sexe;
    }

    public ArrayList<String> getSpecialite() {
        return specialite;
    }

    public void setSpecialite(String[] specialite) {
        this.specialite = new ArrayList<String>(Arrays.asList(specialite));
    }

    @Override
    public String toString() {
        return "Employe@" + Matricule;
    }
}